module com.example.test12dipanshu {
    requires javafx.controls;
    requires javafx.fxml;


    opens com.example.test12dipanshu to javafx.fxml;
    exports com.example.test12dipanshu;
}